package repository;

import java.util.ArrayList;
import java.util.List;

import modelo.Producto;

public class CRUD {
	
	public boolean guardarProductoCompleto(Producto p) {
		return false;
	}
	
	public List<Producto> obtenerProductosEnRiesgo(int stockMinimo) {
		List<Producto> productos = new ArrayList<Producto>();		
		return productos;
	}

}
