package ejerciciosXML.Generos;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.w3c.dom.*;

import java.io.File;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		try {
            File xmlFile = new File("biblio.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();

            NodeList listaLibros = doc.getElementsByTagName("book");

            //Mapa para agrupar por genero
            Map<String, List<String>> librosPorGenero = new HashMap<>();

            for (int i = 0; i < listaLibros.getLength(); i++) {
                Element libro = (Element) listaLibros.item(i);
                String genero = libro.getElementsByTagName("genre").item(0).getTextContent();
                String titulo = libro.getElementsByTagName("title").item(0).getTextContent();

                librosPorGenero.putIfAbsent(genero, new ArrayList<>());
                librosPorGenero.get(genero).add(titulo);
            }

            System.out.println("Libros agrupados por género: ");

            for (String genero : librosPorGenero.keySet()) {
                System.out.println("\n" + genero.toUpperCase() + ":");
                for (String titulo : librosPorGenero.get(genero)) {
                    System.out.println("  - " + titulo);
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
	}

}
