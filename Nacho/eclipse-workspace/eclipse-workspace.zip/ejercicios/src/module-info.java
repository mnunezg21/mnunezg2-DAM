/**
 * 
 */
/**
 * 
 */
module ejercicios {
	requires java.xml;
}