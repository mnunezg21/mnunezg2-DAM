package modelo;

import java.time.LocalDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "ubicacion")
public class Ubicacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ubicacion")
    private int id_ubicacion;

    @Column(name = "pasillo")
    private String pasillo;

    @Column(name = "estanteria")
    private String estanteria;

    @Column(name = "fecha_adquisicion")
    private LocalDate fecha_adquisicion;

    @OneToOne(mappedBy = "ubicacion", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Producto producto;

    public Ubicacion() {}

    public Ubicacion(String pasillo, String estanteria, LocalDate fecha_adquisicion) {
        this.pasillo = pasillo;
        this.estanteria = estanteria;
        this.fecha_adquisicion = fecha_adquisicion;
    }

    public Ubicacion(int id_ubicacion, String pasillo, String estanteria, LocalDate fecha_adquisicion) {
        this.id_ubicacion = id_ubicacion;
        this.pasillo = pasillo;
        this.estanteria = estanteria;
        this.fecha_adquisicion = fecha_adquisicion;
    }

    public int getId_ubicacion() {
        return id_ubicacion;
    }

    public void setId_ubicacion(int id_ubicacion) {
        this.id_ubicacion = id_ubicacion;
    }

    public String getPasillo() {
        return pasillo;
    }

    public void setPasillo(String pasillo) {
        this.pasillo = pasillo;
    }

    public String getEstanteria() {
        return estanteria;
    }

    public void setEstanteria(String estanteria) {
        this.estanteria = estanteria;
    }

    public LocalDate getFecha_adquisicion() {
        return fecha_adquisicion;
    }

    public void setFecha_adquisicion(LocalDate fecha_adquisicion) {
        this.fecha_adquisicion = fecha_adquisicion;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "Ubicacion [id_ubicacion=" + id_ubicacion + ", pasillo=" + pasillo +
               ", estanteria=" + estanteria + ", fecha_adquisicion=" + fecha_adquisicion + "]";
    }
}

