package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import modelo.Categoria;
import modelo.Producto;
import modelo.Ubicacion;
import repository.ProductosRepository;

public class Main {
	
	private static Scanner in = new Scanner(System.in);
	private static final ProductosRepository REPOSITORY = new ProductosRepository();
	private static List<Producto> productos = new ArrayList<Producto>();
	private static List<Object[]> proveedores = new ArrayList<Object[]>();
	
	public static void main(String[] args) {
		int opcion;

		do {
			opcion = menuPrincipal();

			switch(opcion) {
			case 1:
				guardarProducto();
				break;
			case 2:
				System.out.println("Dime el stock minimo por el que buscar: ");
				int stockMinimo = in.nextInt();
				productos = REPOSITORY.obtenerProductosEnRiesgo(stockMinimo);
				System.out.println("Estos son los productos con stock menor a " + stockMinimo);
				for (Producto producto:productos) {
					System.out.println(producto.getNombre());
				}
				break;
			case 3:
				asignarNuevoProveedor();	
				break;
			case 4:
				System.out.print("Dime el ID del producto a borrar: ");
				int id = in.nextInt();
				REPOSITORY.eliminarProductoYUbicacion(id);
				break;
			case 5:
				proveedores = REPOSITORY.obtenerReporteProveedores();
				for (Object[] fila : proveedores) {
				    System.out.println("Proveedor: " + fila[0] + " | Productos: " + fila[1]);
				}
				break;
			case 6:
				System.out.println("Dime el numero del pasillo por el que quieres buscar: ");
				String pasillo = in.next();
				productos = REPOSITORY.obtenerProductosPorPasillo(pasillo);
				for (Producto producto : productos) {
					System.out.println(producto);
				}
				break;
			case 7:
				System.out.println("Dime la categoría que quieres crear:");
			    List<Producto> nuevosProductos = new ArrayList<>();
			    REPOSITORY.crearCategoriaYAsignarProductos(in.next(), nuevosProductos);
			    break;
			case 8:
				System.out.println("Dime la categoría de la que quieres obtener los productos:");
			    productos = REPOSITORY.obtenerProductosDeCategoria(in.next());
			    for (Producto producto : productos) {
			        System.out.println(producto);
			    }
			    break;
			case 9:
			    List<Categoria> categoriasVacias = REPOSITORY.obtenerCategoriasVacias();
			    for (Categoria cat : categoriasVacias) {
			        System.out.println(cat.getNombre());
			    }
			    break;
			case 0:
				System.out.println("Saliendo del programa...");
				break;
			}
		} while (opcion != 0);
	}

	private static int menuPrincipal() {
		System.out.println("""
				---------- MENÚ PRINCIPAL ----------
				1) Insertar Producto
				2) Obtener Productos por stock / Precio > 5
				3) Asignar nuevo Proveedor 
				4) Eliminar Producto
				5) Obtener Reporte Proveedores
				6) Obtener Productos por pasillo
				7) Crear categoría y asignar producto
				8) Ver productos por categoria
				9) Ver categorías vacías
				0) Salir
				""");
		System.out.print("Selecciona una opción: ");
		return in.nextInt();
	}

	private static void guardarProducto() {
	    
	    Ubicacion ubicacion = null;
	    double precio;
	    String nombre, stock;
	    
	    System.out.print("Dime el nombre del producto: ");
	    nombre = in.next();
	    System.out.print("Dime el precio: ");
	    precio = in.nextDouble();
	    System.out.print("Dime su stock: ");
	    stock = in.next();
	    System.out.println("Dime el id de la ubicación: ");
	    ubicacion = REPOSITORY.buscarUbicacion(in.nextInt());
	    
	    Producto pr = new Producto(nombre, stock, precio, ubicacion);
	    
	    REPOSITORY.guardarProductoCompleto(pr);
	}
	
	private static void asignarNuevoProveedor() {
		int id_p;
		int id_pro;
		System.out.print("Dime el ID del producto a cambiar: ");
		id_p = in.nextInt();
		System.out.print("Dime el ID del nuevo proveedor: ");
		id_pro = in.nextInt();
		
		REPOSITORY.asignarNuevoProveedor(id_p, id_pro);		
	}
}
