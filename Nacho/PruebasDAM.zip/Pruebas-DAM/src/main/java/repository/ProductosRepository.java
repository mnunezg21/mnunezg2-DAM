package repository;

import java.util.List;

import org.hibernate.Session;

import modelo.Categoria;
import modelo.Producto;
import modelo.Proveedor;
import modelo.Ubicacion;
import util.HibernateUtil;

public class ProductosRepository {

	public boolean guardarProductoCompleto(Producto p) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		boolean insert = false;

		try {
			session.beginTransaction();
			session.persist(p);
			session.getTransaction().commit();
			insert = true;
		} catch(Exception e) {
			session.getTransaction().rollback();
			System.err.println("Error guardado el producto: " + e.getMessage());
		} finally {
			session.close();
		}
		return insert;
	}

	public List<Producto> obtenerProductosEnRiesgo(int stockMinimo) {

		List<Producto> productos = null;
		Session session = HibernateUtil.getSessionFactory().openSession();

		try {
			session.beginTransaction();

			productos = session.createQuery("FROM Producto p WHERE p.stock < :stockMinimo AND p.precio > 5.00", Producto.class)
					.setParameter("stockMinimo", stockMinimo)
					.list();

			session.getTransaction().commit();

		} catch(Exception e) {
			session.getTransaction().rollback();
			System.err.println("Error guardado los produc: " + e.getMessage());
		} finally {
			session.close();
		}
		return productos;
	}

	public boolean asignarNuevoProveedor(int idProducto, int idProveedorNuevo) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		boolean isUpdate = false;
		Producto producto = null;
		Proveedor proveedor= null;

		try {
			session.beginTransaction();

			producto = session.createQuery("FROM Producto p WHERE id_producto = :idProducto ", Producto.class)
					.setParameter("idProducto", idProducto).getSingleResult();

			proveedor = session.createQuery("FROM Proveedor p WHERE id_proveedor = :idProveedor ", Proveedor.class)
					.setParameter("idProveedor", idProveedorNuevo).getSingleResult();

			producto.getProveedores().add(proveedor);

			session.persist(producto);

			session.getTransaction().commit();
		} catch(Exception e) {
			session.getTransaction().rollback();
			System.err.println("Error asignando un nuevo proveedor: " + e.getMessage());
		} finally {
			session.close();
		}

		return isUpdate;
	}

	public boolean eliminarProductoYUbicacion(int idProducto) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		boolean isDelete = false;
		Producto producto;

		try {
			session.beginTransaction();
			producto = session.get(Producto.class, idProducto);

			if (producto != null) {
				session.remove(producto);
				session.getTransaction().commit();
				isDelete = true;
			}

			session.getTransaction().rollback();
		} catch (Exception e) {
			session.getTransaction().rollback();
		} finally {
			session.close();
		}

		return isDelete;
	}

	public List<Object[]> obtenerReporteProveedores() {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    List<Object[]> reporte = null;

	    try {
	        session.beginTransaction();

	        String hql =
	            "SELECT pr.nombre, COUNT(p.id_producto) " +
	            "FROM Proveedor pr " +
	            "JOIN pr.productos p " +
	            "GROUP BY pr.nombre " +
	            "ORDER BY COUNT(p.id_producto) DESC";

	        reporte = session.createQuery(hql, Object[].class).list();

	        session.getTransaction().commit();
	    } catch (Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error obteniendo reporte de proveedores: " + e.getMessage());
	    } finally {
	        session.close();
	    }

	    return reporte;
	}

	

	public List<Producto> obtenerProductosPorPasillo(String pasillo) {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    List<Producto> productos = null;

	    try {
	        session.beginTransaction();

	        String hql = "FROM Producto p WHERE p.ubicacion.pasillo = :pasillo";

	        productos = session.createQuery(hql, Producto.class)
	                .setParameter("pasillo", pasillo)
	                .list();

	        session.getTransaction().commit();
	    } catch (Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error obteniendo productos por pasillo: " + e.getMessage());
	    } finally {
	        session.close();
	    }

	    return productos;
	}

	public Ubicacion buscarUbicacion(int idUbicacion) {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    Ubicacion ubicacion = null;

	    try {
	        session.beginTransaction();

	        String hql = "FROM Ubicacion u WHERE u.id_ubicacion = :idUbicacion";

	        ubicacion = session.createQuery(hql, Ubicacion.class)
	                .setParameter("idUbicacion", idUbicacion)
	                .uniqueResult();

	        session.getTransaction().commit();
	    } catch (Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error obteniendo ubicación: " + e.getMessage());
	    } finally {
	        session.close();
	    }

	    return ubicacion;
	}


	public boolean crearCategoriaYAsignarProductos(String nombreCategoria, List<Producto> productos) {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    boolean success = false;
	    
	    try {
	        session.beginTransaction();
	        
	        Categoria categoria = new Categoria(nombreCategoria);
	        for(Producto producto : productos) {
	            producto.setCategoria(categoria);
	            categoria.getProductos().add(producto);
	        }
	        
	        session.persist(categoria);
	        session.getTransaction().commit();
	        success = true;
	        
	    } catch(Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error creando categoría: " + e.getMessage());
	    } finally {
	        session.close();
	    }
	    
	    return success;
	}

	public List<Producto> obtenerProductosDeCategoria(String nombreCategoria) {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    List<Producto> productos = null;
	    
	    try {
	        session.beginTransaction();
	        
	        String hql = "FROM Producto p WHERE p.categoria.nombre = :nombreCategoria";
	        productos = session.createQuery(hql, Producto.class)
	                .setParameter("nombreCategoria", nombreCategoria)
	                .list();
	                
	        session.getTransaction().commit();
	    } catch(Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error obteniendo productos por categoría: " + e.getMessage());
	    } finally {
	        session.close();
	    }
	    
	    return productos;
	}

	public List<Categoria> obtenerCategoriasVacias() {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    List<Categoria> categorias = null;
	    
	    try {
	        session.beginTransaction();
	        
	        String hql = "FROM Categoria c WHERE c.productos IS EMPTY";
	        categorias = session.createQuery(hql, Categoria.class).list();
	                
	        session.getTransaction().commit();
	    } catch(Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error obteniendo categorías vacías: " + e.getMessage());
	    } finally {
	        session.close();
	    }
	    
	    return categorias;
	}

	public boolean moverProductosDeCategoria(String catOrigen, String catDestino) {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    boolean success = false;
	    
	    try {
	        session.beginTransaction();
	        
	        Categoria origen = session.createQuery("FROM Categoria c WHERE c.nombre = :nombre", Categoria.class)
	                .setParameter("nombre", catOrigen)
	                .uniqueResult();
	        Categoria destino = session.createQuery("FROM Categoria c WHERE c.nombre = :nombre", Categoria.class)
	                .setParameter("nombre", catDestino)
	                .uniqueResult();
	        
	        if(origen != null && destino != null) {
	            for(Producto producto : origen.getProductos()) {
	                producto.setCategoria(destino);
	                destino.getProductos().add(producto);
	            }
	            origen.getProductos().clear();
	            
	            session.merge(origen);
	            session.merge(destino);
	        }
	        
	        session.getTransaction().commit();
	        success = true;
	        
	    } catch(Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error moviendo productos: " + e.getMessage());
	    } finally {
	        session.close();
	    }
	    
	    return success;
	}

	public List<Object[]> obtenerResumenCategoria() {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    List<Object[]> resumen = null;
	    
	    try {
	        session.beginTransaction();
	        
	        String hql = "SELECT c.nombre, COUNT(p), AVG(p.precio) " +
	                     "FROM Categoria c LEFT JOIN c.productos p " +
	                     "GROUP BY c.nombre";
	                     
	        resumen = session.createQuery(hql, Object[].class).list();
	                
	        session.getTransaction().commit();
	    } catch(Exception e) {
	        session.getTransaction().rollback();
	        System.err.println("Error obteniendo resumen: " + e.getMessage());
	    } finally {
	        session.close();
	    }
	    
	    return resumen;
	}
}
