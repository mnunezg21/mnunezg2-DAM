package com.mnunezg.contador

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mnunezg.contador.ui.theme.ContadorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ContadorTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    CounterScreen(name = "Contador", modifier = Modifier.padding(innerPadding))

                }
            }
        }
    }
}

@Composable
fun CounterScreen(name: String, modifier: Modifier = Modifier) {
    var contador: Int by rememberSaveable { mutableStateOf(0) }
    val colores: List<Color> = listOf(Color.Blue,Color.Green,Color.Red,Color.Cyan,Color.Magenta)
    Column(
        modifier = modifier.fillMaxSize().padding(16.dp).clickable(onClick = {contador++}).background(colores.random()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally

    ) {
        Contador(contador = contador,
            OnIncrease = {contador++},
            OnDecrease={if (contador > 0 ) contador--})

    }
}


//OnIncrease sirve para incrementar
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Contador(contador: Int, OnIncrease: () -> Unit, OnDecrease : () -> Unit) {
    var num: Int by rememberSaveable { mutableStateOf(0) }
    Text("${contador.toString()}",
        fontSize = if (contador<100)(64+contador/3).sp else 100.sp,
        modifier = Modifier.combinedClickable(
            onClick = { OnIncrease() },
            onLongClick = {OnDecrease()}
            ))
    Button(onClick = { OnIncrease() }) { Text("Click") }
}