package com.antpaniagua.t401sharedpreferences.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import com.antpaniagua.t401sharedpreferences.data.palabrasSet
import com.antpaniagua.t401sharedpreferences.ui.MainUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update


/**
 * MainViewModel contiene el Viewmodel empleado para actualizar el interface
 * Enero de 2025
 * @author Antonio Paniagua Navarro
 *
 * En este ejemplo de estudio se prueban diferentes fórmulas de trabajo. No se debe considerar como
 * la única forma de hacerlo ni la forma correcta. Lee los comentarios.
 */

class MainViewModel() : ViewModel() {
    private val KEY_LASTWORD = "ultima_palabra"
    private val KEY_TEXT = "text"
    private val KEY_NUMPAUSE = "times_paused"
    private val KEY_NUMSTOP = "times_stopped"
    private val PREFSFILE = "palabra_preferences.dat"
    private val LOGTAG = "DAMPREFS VIEWMODEL"

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        getPalabraRandom()
        Log.d(LOGTAG, "Conjunto de palabras: $palabrasSet")
    }

    /**
     * Genera una palabra aleatoria y actualiza el contador de palabras
     */
    fun getPalabraRandom() {
        //Vincula el estado con una variable aleatoria y con el número de palabras
        _uiState.value = MainUiState(palabraActual = palabrasSet.random(),
            numPalabrasMostradas = _uiState.value.numPalabrasMostradas,
            vecesPausado = _uiState.value.vecesPausado, //observa la recomposición si se comenta esta línea
            vecesDetenido = _uiState.value.vecesDetenido)
        //Esto funciona correctamente porque más arriva se ha vinculado _uistate con mainUiState
        //_uiState.value.numPalabrasMostradas++
        //Esta segunda fórmula permite usar val en lugar de var en la definición del objeto
        _uiState.update { estadoActual -> estadoActual.copy(numPalabrasMostradas = _uiState.value.numPalabrasMostradas+1) }
        Log.d(LOGTAG,"Estado actual: ${_uiState.value.toString()}")

    }

    fun setPalabraActual(palabra: String) {
        uiState.value.palabraActual = palabra
    }

    fun getPalabraActual(): String {
        return uiState.value.palabraActual
    }

    /**
     * Guarda las preferencias. Empleamos la fórmula extendida
     *
     * Usar el contexto en un viewmodel no es lo más recomendable, pero...
     */
    fun savePreferences(context: Context, lastWord: String) {
        val editor =
            context.getSharedPreferences(PREFSFILE, Context.MODE_PRIVATE).edit()
        editor.putString(KEY_LASTWORD, lastWord)
        editor.apply()
    }

    /**
     * Inicializa las preferencias una primera vez
     */
    fun loadFirstPreferences(context: Context){
        getVecesPausado(context)
        getVecesDetenido(context)
    }

    // Función para cargar preferencias
    fun loadPreferenceLastWord(context: Context): String? {
        val lastWord = context.getSharedPreferences(PREFSFILE, Context.MODE_PRIVATE).getString(KEY_LASTWORD, null)
        return lastWord
    }

    fun getVecesPausado(context: Context) {
        val vecesPausado: Int =
            context.getSharedPreferences(PREFSFILE, Context.MODE_PRIVATE)
                .getInt(KEY_NUMPAUSE, 0)
        uiState.value.vecesPausado = vecesPausado
    }

    fun getVecesDetenido(context: Context) {
        val cantidad:Int = context.getSharedPreferences(PREFSFILE, Context.MODE_PRIVATE)
            .getInt(KEY_NUMSTOP, 0)

        //Otra forma de actualizar un objeto observado por un estado es mediante una copia
        _uiState.update { estadoActual -> estadoActual.copy(vecesDetenido = cantidad) }
    }
}