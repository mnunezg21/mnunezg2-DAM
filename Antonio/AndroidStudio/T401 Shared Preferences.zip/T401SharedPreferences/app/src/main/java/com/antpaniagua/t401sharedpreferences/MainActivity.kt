package com.antpaniagua.t401sharedpreferences

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.antpaniagua.t401sharedpreferences.ui.MainScreen
import com.antpaniagua.t401sharedpreferences.ui.theme.T401SharedPreferencesTheme

/**
 * Preferences y SharedPreferences
 *
 * Aunque la alternativa actual es DataStore, el uso de preferences para guardar pares clave-valor
 * sencillos es una opción igualmente válida.
 *
 * La aplicación almacena diferentes valores en las preferencias de la aplicación ante determinadas
 * pulsaciones y eventos.
 */

//Para prevenir errores, declaramos los nombres de las claves como constantes.
private val KEY_TEXT = "text"
private val KEY_NUMPAUSE = "times_paused"
private val KEY_NUMSTOP = "times_stopped"
private val LOGTAG = "DAMPREFS ACTIVITY"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            T401SharedPreferencesTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MainScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }

    /**
     * onResume()
     *
     * Al pasar a primer plano en onResume, se cargan las preferencias y se muestran sus valores
     * en el log.
     *
     * Esta función no provoca una recomposición de la pantalla, motivo por el que si el interface
     * pasó a un segundo plano no se actualizarán y los valores en el log serán más altos que en
     * el interface en algunas circustancias. Lo corregimos en la clase MainScreen.
     */
    override fun onResume() {
        super.onResume()
        val preferencias = getSharedPreferences("palabra_preferences.dat", MODE_PRIVATE)
        Log.i(LOGTAG, "Resume. Mensaje       : ${preferencias.getString(KEY_TEXT, "")}")
        Log.i(LOGTAG, "Resume. Veces detenido: ${preferencias.getInt(KEY_NUMSTOP, 0).toString()}")
        Log.i(LOGTAG, "Resume. Veces pausado : ${preferencias.getInt(KEY_NUMPAUSE, 0).toString()}")
    }

    /**
     * onPause()
     *
     * Al pausar también se guarda un valor.
     *
     * Dentro de la clase principal no es preciso indicar el contexto, ya que es una Actividad.
     */
    override fun onPause() {
        super.onPause()
        val preferencias = getSharedPreferences("palabra_preferences.dat", MODE_PRIVATE)
        val numVecesPausado = preferencias.getInt(KEY_NUMPAUSE, 0)
        preferencias.edit().putInt(KEY_NUMPAUSE, numVecesPausado + 1).commit()
        Log.i(LOGTAG, "Pause. La aplicación se ha puesto en pausa")
    }

    /**
     * onDestroy()
     *
     * Al pasar por el onDestroy, esta clase guarda un mensaje de prueba en las preferencias de la
     * aplicación, así como el número de veces que se ha detenido.
     */
    override fun onDestroy() {
        super.onDestroy()
        val preferencias = getSharedPreferences("palabra_preferences.dat", MODE_PRIVATE)
        preferencias.edit().putString(KEY_TEXT, "Palabras preferencias").commit()
        val numVecesDetenido = preferencias.getInt(KEY_NUMSTOP, 0)
        preferencias.edit().putInt(KEY_NUMSTOP, numVecesDetenido + 1).commit()
        Log.i(LOGTAG, "Stop. Aplicación detenida. Preferencias guardadas")
    }
}