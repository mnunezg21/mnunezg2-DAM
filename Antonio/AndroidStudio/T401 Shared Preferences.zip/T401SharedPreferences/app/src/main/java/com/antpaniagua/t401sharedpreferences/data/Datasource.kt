package com.antpaniagua.t401sharedpreferences.data

const val MAX = 3

//Un set no admite duplicados, al contrario que una lista. Por eso el listado de palabras contendrá
//menos valores de los que vemos aquí.
val palabrasSet: Set<String> = setOf("sol",
    "luna",
    "marte",
    "mercurio",
    "saturno",
    "jupiter",
    "venus",
    "plutón",
    "plutón",
    "plutón",
    "plutón",
    "plutón",
    "plutón",)