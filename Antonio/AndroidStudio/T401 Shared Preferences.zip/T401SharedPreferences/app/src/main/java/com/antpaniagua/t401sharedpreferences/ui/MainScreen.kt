package com.antpaniagua.t401sharedpreferences.ui

import android.app.Activity
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.antpaniagua.t401sharedpreferences.viewmodel.MainViewModel
import kotlinx.coroutines.delay

private val LOGTAG = "DAMPREFS SCREEN"

@Composable
fun MainScreen(modifier: Modifier) {
    val context = LocalContext.current
    val viewModel: MainViewModel = viewModel()
    viewModel.loadFirstPreferences(context)
    val mainUiState by viewModel.uiState.collectAsState()
    Log.d(LOGTAG, "Última palabra: ${viewModel.loadPreferenceLastWord(context)}")
    viewModel.setPalabraActual(viewModel.loadPreferenceLastWord(context).toString())
    MainLayout(modifier, onChangeWord = {
        viewModel.getPalabraRandom()
        viewModel.savePreferences(context, viewModel.getPalabraActual())
        viewModel.getVecesPausado(context = context)
        viewModel.getVecesDetenido(context = context)
    }, onSideEffectCompleted = { Toast.makeText(context, "Jugando con los efectos. Han pasado unos segundos", Toast.LENGTH_SHORT).show()})

    //Asociado al rememberLifecycleEvent de abajo. Usamos esto para actualizar el número de veces
    //que se pausa la aplicación.
    //Esto no suele ser necesario. Lo hacemos para poder controlar un evento de la aplicación desde
    //Jetpack Compose y generar así la recomposición.
    //Fuente: https://proandroiddev.com/jetpack-compose-making-composable-lifecycle-aware-bde67437d2d0
    val lifecycleEvent = rememberLifecycleEvent()
    Log.d(LOGTAG, "Lifecycle event: $lifecycleEvent")

    //En este caso LaunchedEffect no sería necesario
    //LaunchedEffect(lifecycleEvent) {
        if (lifecycleEvent == Lifecycle.Event.ON_RESUME) {
            viewModel.getVecesPausado(context = context)
        }
   // }
}

@Composable
fun MainLayout(modifier: Modifier, onChangeWord: () -> Unit, onSideEffectCompleted: () -> Unit ) {
    val mainViewModel: MainViewModel = viewModel()
    val mainUiState by mainViewModel.uiState.collectAsState()
    Column(
        modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(
            Modifier
                .size(48.dp)
        )
        Text(
            text = "DAM. Almacenamiento de preferencias",
            fontSize = 24.sp,
            textAlign = TextAlign.Center
        )
        Spacer(
            Modifier
                .size(12.dp)
        )
        Text(
            text = "Observa el catlog con detenimiento. Se trabajan dos cuestiones: preferencias y efectos",
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        Spacer(
            Modifier
                .size(48.dp).weight(1f)
        )
        Text(
            text = mainUiState.palabraActual,
            fontSize = 24.sp
        )
        Spacer(Modifier.size(24.dp))
        Button(onClick = {
            onChangeWord()
        }) {
            Text("Cambiar palabra")
        }
        Spacer(modifier = Modifier.weight(1f))
        Text("Estadísticas", fontSize = 14.sp)
        Text("Palabras mostradas: ${mainUiState.numPalabrasMostradas}")
        Text("Veces pausada: ${mainUiState.vecesPausado}")
        Text("Veces detenida: ${mainUiState.vecesDetenido}")
        Spacer(modifier = Modifier.size(12.dp))
    }

    if (mainUiState.numPalabrasMostradas % 5 == 0) {
        DialogoAlerta(onContinuar = { mainViewModel.getPalabraRandom() })
    }

    /** Vamos a simular aquí el uso de un efecto
     * Si intentamos hacer un delay no será posible
     * delay(2000)
     * puesto que detendría el hilo principal. Para ello se lanzan en coroutinas (con suspend, p.e.)
     *
     * Otra alternativa consiste en lanzarlo dentro de un efecto colateral (side-effect)
     * mediante LaunchedEffect, que va a generar una corutina dentro del ámbito del efecto.
     * Esta corutina puede usar callbacks para informar de lo que sucede dentro de ella o no pasar nada
     * Usamos Unit generalmente y recordamos el estadomediante una variable para asegurarnos de que siempre
     * recordamos el estado del efecto (mediante rememberUpdateState)
     *
     * Más en el siguiente codelab:
     * https://developer.android.com/codelabs/jetpack-compose-advanced-state-side-effects#4
     */

    LaunchedEffect(Unit) {
        delay(10000)
        Log.d(LOGTAG, "Han pasado unos segundos dentro del efecto. El hilo principal no se ha visto afectado")
    }

    val currentOnSideEffectCompleted by rememberUpdatedState(onSideEffectCompleted)
    LaunchedEffect(Unit) {
        delay(5000)
        currentOnSideEffectCompleted()
    }
}

@Composable
fun DialogoAlerta(onContinuar: () -> Unit) {
    //Capturamos la actividad para usar su contexto
    val activity = (LocalContext.current as Activity)
    AlertDialog(
        onDismissRequest = { /*TODO*/ },
        title = { Text("Palabras Preferences") },
        text = { Text("Hemos mostrado cinco palabras, ¿quiére continuar?") },
        dismissButton = {
            TextButton(
                onClick = {
                    activity.finish()
                }
            ) {
                Text("Es suficiente, salir")
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onContinuar()
                }
            ) {
                Text("Unas palabras más")
            }
        }
    )
}

@Composable
fun rememberLifecycleEvent(lifecycleOwner: LifecycleOwner = LocalLifecycleOwner.current): Lifecycle.Event {
    var lifecycleEvent by remember { mutableStateOf(Lifecycle.Event.ON_ANY) }
    DisposableEffect(lifecycleOwner) {
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            lifecycleEvent = event
        }

        lifecycleOwner.lifecycle.addObserver(lifecycleObserver)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
        }
    }
    return  lifecycleEvent
}

//@Composable
//@Preview
//fun MainScreenPreview() {
//    val context = LocalContext.current
//    val mainUiState by mainViewModel.uiState.collectAsState()
//    mainViewModel.setPalabraActual(mainViewModel.loadPreferenceLastWord(context).toString())
//    MainLayout(mainViewModel, onChangeWord = {
//        mainViewModel.getPalabraRandom()
//        mainViewModel.savePreferences(context, mainViewModel.getPalabraActual())
//    })
//}