package com.antpaniagua.t401sharedpreferences.ui

/**
 * Generamos una clase UIState que contendrá los valores que queremos modificar en el
 * interface. Una clase contenedora de estados.
 *
 */

data class MainUiState(
    var palabraActual: String = "",
    val numPalabrasMostradas: Int = 0,
    var vecesDetenido: Int = 0,
    var vecesPausado: Int = 0,
)
