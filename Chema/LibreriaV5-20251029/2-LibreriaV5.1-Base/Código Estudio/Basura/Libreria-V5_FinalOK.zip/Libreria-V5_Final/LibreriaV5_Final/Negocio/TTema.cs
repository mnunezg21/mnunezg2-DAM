﻿
namespace LibreriaV5_Final.Negocio
{
    class TTema
    {
        public string Tema { get; set; }

        public TTema()
        {
        }

        public TTema(string tema)
        {
            this.Tema = tema;
        }


    }
}
